import React, { useState } from 'react';
import { Menu, Search, Bell, User, Home, Compass, PlaySquare, Clock, ThumbsUp, Film, Play } from 'lucide-react';
import Sidebar from './components/Sidebar';
import VideoGrid from './components/VideoGrid';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-14 bg-[#0f0f0f] flex items-center justify-between px-4 z-50">
        <div className="flex items-center gap-4">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-[#272727] rounded-full">
            <Menu size={20} />
          </button>
          <a href="/" className="flex items-center gap-1">
            <div className="relative">
              <div className="bg-red-600 rounded-lg p-1">
                <Play size={20} fill="white" className="ml-0.5" />
              </div>
            </div>
            <span className="font-semibold text-lg">YouTube</span>
          </a>
        </div>
        
        <div className="flex-1 max-w-2xl mx-4">
          <div className="flex">
            <div className="flex-1 flex items-center bg-[#121212] border border-[#303030] rounded-l-full px-4">
              <input
                type="text"
                placeholder="Search"
                className="w-full bg-transparent outline-none py-2"
              />
            </div>
            <button className="px-6 bg-[#272727] border-y border-r border-[#303030] rounded-r-full hover:bg-[#3f3f3f]">
              <Search size={20} />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-[#272727] rounded-full">
            <Bell size={20} />
          </button>
          <button className="p-2 hover:bg-[#272727] rounded-full">
            <User size={20} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex pt-14">
        <Sidebar isOpen={sidebarOpen} />
        <main className="flex-1 p-4 ml-0 md:ml-[240px]">
          {/* Categories */}
          <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
            {['All', 'Gaming', 'Music', 'Live', 'Podcasts', 'Computer Science', 'Apple', 'Recently uploaded'].map((category) => (
              <button
                key={category}
                className="px-3 py-1.5 bg-[#272727] rounded-lg whitespace-nowrap hover:bg-[#3f3f3f]"
              >
                {category}
              </button>
            ))}
          </div>
          
          <VideoGrid />
        </main>
      </div>
    </div>
  );
}

export default App;