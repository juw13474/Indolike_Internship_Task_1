import React from 'react';
import { Home, Compass, PlaySquare, Clock, ThumbsUp, Film, Flame, ShoppingBag, Music2, Gamepad2, Newspaper, Trophy, Lightbulb } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const menuItems = [
    { icon: Home, label: 'Home' },
    { icon: Compass, label: 'Explore' },
    { icon: PlaySquare, label: 'Subscriptions' },
    { icon: Film, label: 'Library' },
    { icon: Clock, label: 'History' },
    { icon: ThumbsUp, label: 'Liked videos' },
    { icon: Flame, label: 'Trending' },
    { icon: ShoppingBag, label: 'Shopping' },
    { icon: Music2, label: 'Music' },
    { icon: Gamepad2, label: 'Gaming' },
    { icon: Newspaper, label: 'News' },
    { icon: Trophy, label: 'Sports' },
    { icon: Lightbulb, label: 'Learning' },
  ];

  if (!isOpen) return null;

  return (
    <aside className="fixed left-0 top-14 bottom-0 w-60 bg-[#0f0f0f] overflow-y-auto hidden md:block">
      <div className="py-2">
        {menuItems.map((item) => (
          <a
            key={item.label}
            href="#"
            className="flex items-center gap-6 px-6 py-2 hover:bg-[#272727]"
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </a>
        ))}
      </div>
    </aside>
  );
};

export default Sidebar;