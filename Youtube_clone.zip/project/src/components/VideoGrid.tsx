import React from 'react';

const videos = [
  {
    id: 1,
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&q=80',
    title: 'Building a Modern Web Application with React',
    channel: 'Tech Academy',
    views: '120K views',
    timestamp: '2 days ago',
    duration: '15:24',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80'
  },
  {
    id: 2,
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&q=80',
    title: 'Complete JavaScript Course 2024',
    channel: 'Code Masters',
    views: '89K views',
    timestamp: '1 week ago',
    duration: '22:15',
    avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&q=80'
  },
  {
    id: 3,
    thumbnail: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&q=80',
    title: 'UI/UX Design Principles',
    channel: 'Design Hub',
    views: '45K views',
    timestamp: '3 days ago',
    duration: '18:30',
    avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&q=80'
  },
  {
    id: 4,
    thumbnail: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800&q=80',
    title: 'Mobile App Development Tutorial',
    channel: 'App Academy',
    views: '67K views',
    timestamp: '5 days ago',
    duration: '25:45',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&q=80'
  },
  {
    id: 5,
    thumbnail: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&q=80',
    title: 'Data Structures and Algorithms',
    channel: 'CS Fundamentals',
    views: '92K views',
    timestamp: '1 day ago',
    duration: '32:10',
    avatar: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=100&q=80'
  },
  {
    id: 6,
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&q=80',
    title: 'Full Stack Development Crash Course',
    channel: 'Web Ninja',
    views: '150K views',
    timestamp: '4 days ago',
    duration: '28:55',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&q=80'
  },
  {
    id: 7,
    thumbnail: 'https://images.unsplash.com/photo-1593720213428-28a5b9e94613?w=800&q=80',
    title: 'Advanced TypeScript Patterns',
    channel: 'TypeScript Guru',
    views: '78K views',
    timestamp: '6 days ago',
    duration: '42:18',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80'
  },
  {
    id: 8,
    thumbnail: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80',
    title: 'Game Development with Unity',
    channel: 'Game Dev Pro',
    views: '234K views',
    timestamp: '1 week ago',
    duration: '1:15:30',
    avatar: 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=100&q=80'
  },
  {
    id: 9,
    thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80',
    title: 'Cybersecurity Fundamentals',
    channel: 'Security First',
    views: '167K views',
    timestamp: '3 days ago',
    duration: '55:42',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80'
  },
  {
    id: 10,
    thumbnail: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=800&q=80',
    title: 'Machine Learning for Beginners',
    channel: 'AI Academy',
    views: '198K views',
    timestamp: '4 days ago',
    duration: '48:25',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80'
  },
  {
    id: 11,
    thumbnail: 'https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=800&q=80',
    title: 'Blockchain Development Tutorial',
    channel: 'Crypto Dev',
    views: '145K views',
    timestamp: '2 weeks ago',
    duration: '1:02:15',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&q=80'
  },
  {
    id: 12,
    thumbnail: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&q=80',
    title: 'DevOps Pipeline Automation',
    channel: 'Cloud Experts',
    views: '88K views',
    timestamp: '5 days ago',
    duration: '36:50',
    avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&q=80'
  }
];

const VideoGrid: React.FC = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {videos.map((video) => (
        <div key={video.id} className="cursor-pointer">
          <div className="relative">
            <img
              src={video.thumbnail}
              alt={video.title}
              className="w-full aspect-video object-cover rounded-xl"
            />
            <span className="absolute bottom-2 right-2 bg-black bg-opacity-80 px-2 py-1 text-xs rounded">
              {video.duration}
            </span>
          </div>
          <div className="flex gap-3 mt-3">
            <img
              src={video.avatar}
              alt={video.channel}
              className="w-9 h-9 rounded-full"
            />
            <div>
              <h3 className="font-medium line-clamp-2">{video.title}</h3>
              <p className="text-sm text-gray-400 mt-1">{video.channel}</p>
              <p className="text-sm text-gray-400">
                {video.views} • {video.timestamp}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default VideoGrid;