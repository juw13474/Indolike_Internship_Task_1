I've created a modern YouTube clone with the following features:

Responsive layout with a collapsible sidebar
Dark theme matching YouTube's design
Video grid with thumbnails, titles, and metadata
Search bar with YouTube-like styling
Category pills for filtering content
Navigation sidebar with common YouTube sections
Custom scrollbar styling
Proper loading of video thumbnails and channel avatars
Hover effects and interactions
The application uses:

Tailwind CSS for styling
Lucide React for icons
React hooks for state management
TypeScript for type safety
Responsive design that works on all screen sizes
The development server is now running. You can see a fully functional YouTube clone interface with a modern, 
clean design that closely matches YouTube's actual layout and functionality.

Run Application:

npx vite build
npm run dev